import pickle
import numpy as np
import os
from django.shortcuts import render

# Define absolute paths for model & scaler
MODEL_PATH = r"C:\Users\hkask\PycharmProjects\MINI_PROJECT\static\diabetes_prediction\images\new_model.pkl"
SCALER_PATH = r"C:\Users\hkask\scaler.pkl"  # Ensure this file exists

# Load the trained model
try:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    print("✅ Model loaded successfully.")
except Exception as e:
    model = None
    print(f"❌ Error loading model: {str(e)}")

# Load the scaler (if used during training)
try:
    with open(SCALER_PATH, "rb") as f:
        scaler = pickle.load(f)
    print("✅ Scaler loaded successfully.")
except Exception as e:
    scaler = None  # Proceed without scaling
    print(f"⚠️ Warning: Scaler not found! Model might give incorrect results. {str(e)}")

# Home Page
def home(request):
    return render(request, "home.html")

# Prediction Function
def predict(request):
    if request.method == "POST":
        try:
            # Extract input values from form
            user_input = [
                request.POST["n1"],
                request.POST["n2"],
                request.POST["n3"],
                request.POST["n4"],
                request.POST["n5"],
                request.POST["n6"],
                request.POST["n7"],
                request.POST["n8"]
            ]

            # Convert to float & handle potential input errors
            try:
                input_data = np.array([list(map(float, user_input))])
            except ValueError:
                return render(request, "predict.html", {"result": "⚠️ Invalid input. Please enter numeric values only."})

            print(f"🔍 Raw Input Data: {input_data}")  # Debugging

            # Apply scaling if a scaler was used during training
            if scaler:
                input_data = scaler.transform(input_data)
                print(f"📏 Scaled Input Data: {input_data}")  # Debugging

            # Ensure model is loaded before predicting
            if model:
                prediction = model.predict(input_data)
                print(f"🔮 Raw Model Output: {prediction}")  # Debugging

                # Interpret the prediction result
                result = "🔴 You are prone to be diabetic" if prediction[0] == 1 else "🟢 Not Diabetic"
            else:
                result = "❌ Error: Model not found!"

            return render(request, "predict.html", {"result": result})

        except Exception as e:
            print(f"❌ Error: {str(e)}")  # Log error for debugging
            return render(request, "predict.html", {"result": f"❌ Error: {str(e)}"})

    return render(request, "predict.html", {"result": ""})
