# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt

# Step 1: Load and Preprocess Data
url = 'https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv'
column_names = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age', 'Outcome']
df = pd.read_csv(url, names=column_names)

# Checking for missing values
df.isnull().sum()

# Split into features (X) and target (y)
X = df.drop(columns=['Outcome'])
y = df['Outcome']

# Step 2: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 3: Feature Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Step 4: Model Definitions and Hyperparameter Tuning

# Logistic Regression Hyperparameters
param_grid_lr = {
    'C': [0.01, 0.1, 1, 10],
    'solver': ['liblinear', 'saga'],
    'max_iter': [100, 200, 500]
}
log_reg = GridSearchCV(LogisticRegression(random_state=42), param_grid_lr, cv=5, scoring='accuracy')
log_reg.fit(X_train_scaled, y_train)

# Random Forest Hyperparameters
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [5, 10, 15, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}
rf = GridSearchCV(RandomForestClassifier(random_state=42), param_grid_rf, cv=5, scoring='accuracy')
rf.fit(X_train, y_train)

# Decision Tree Hyperparameters
param_grid_dt = {
    'max_depth': [5, 10, 15, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'criterion': ['gini', 'entropy']
}
dt = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid_dt, cv=5, scoring='accuracy')
dt.fit(X_train, y_train)

# Step 5: Voting Classifier (Ensemble)
voting_clf = VotingClassifier(
    estimators=[('log_reg', log_reg.best_estimator_),
                ('rf', rf.best_estimator_),
                ('dt', dt.best_estimator_)],
    voting='hard'  # 'hard' voting for class prediction
)
voting_clf.fit(X_train, y_train)

# Step 6: Evaluate the Models

# Get predictions from all models
y_pred_log_reg = log_reg.predict(X_test_scaled)
y_pred_rf = rf.predict(X_test)
y_pred_dt = dt.predict(X_test)
y_pred_voting = voting_clf.predict(X_test)

# Accuracy Scores
log_reg_accuracy = accuracy_score(y_test, y_pred_log_reg)
rf_accuracy = accuracy_score(y_test, y_pred_rf)
dt_accuracy = accuracy_score(y_test, y_pred_dt)
voting_accuracy = accuracy_score(y_test, y_pred_voting)

print(f'Logistic Regression Accuracy: {log_reg_accuracy}')
print(f'Random Forest Accuracy: {rf_accuracy}')
print(f'Decision Tree Accuracy: {dt_accuracy}')
print(f'Voting Classifier Accuracy: {voting_accuracy}')
# AUC Scores
log_reg_auc = roc_auc_score(y_test, log_reg.predict_proba(X_test_scaled)[:, 1])
rf_auc = roc_auc_score(y_test, rf.predict_proba(X_test)[:, 1])
dt_auc = roc_auc_score(y_test, dt.predict_proba(X_test)[:, 1])
voting_auc = roc_auc_score(y_test, voting_clf.predict_proba(X_test)[:, 1])

print(f'Logistic Regression AUC: {log_reg_auc}')
print(f'Random Forest AUC: {rf_auc}')
print(f'Decision Tree AUC: {dt_auc}')
print(f'Voting Classifier AUC: {voting_auc}')

# ROC Curve
fpr_log_reg, tpr_log_reg, _ = roc_curve(y_test, log_reg.predict_proba(X_test_scaled)[:, 1])
fpr_rf, tpr_rf, _ = roc_curve(y_test, rf.predict_proba(X_test)[:, 1])
fpr_dt, tpr_dt, _ = roc_curve(y_test, dt.predict_proba(X_test)[:, 1])
fpr_voting, tpr_voting, _ = roc_curve(y_test, voting_clf.predict_proba(X_test)[:, 1])

plt.figure(figsize=(10,6))
plt.plot(fpr_log_reg, tpr_log_reg, label=f'Logistic Regression AUC = {log_reg_auc:.2f}')
plt.plot(fpr_rf, tpr_rf, label=f'Random Forest AUC = {rf_auc:.2f}')
plt.plot(fpr_dt, tpr_dt, label=f'Decision Tree AUC = {dt_auc:.2f}')
plt.plot(fpr_voting, tpr_voting, label=f'Voting Classifier AUC = {voting_auc:.2f}')
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend(loc='lower right')
plt.show()

# Step 7: Cross-validation for better estimates
cross_val_log_reg = cross_val_score(log_reg.best_estimator_, X_train_scaled, y_train, cv=5, scoring='accuracy').mean()
cross_val_rf = cross_val_score(rf.best_estimator_, X_train, y_train, cv=5, scoring='accuracy').mean()
cross_val_dt = cross_val_score(dt.best_estimator_, X_train, y_train, cv=5, scoring='accuracy').mean()
cross_val_voting = cross_val_score(voting_clf, X_train, y_train, cv=5, scoring='accuracy').mean()

print(f'Cross-validation Accuracy for Logistic Regression: {cross_val_log_reg}')
print(f'Cross-validation Accuracy for Random Forest: {cross_val_rf}')
print(f'Cross-validation Accuracy for Decision Tree: {cross_val_dt}')
print(f'Cross-validation Accuracy for Voting Classifier: {cross_val_voting}')
