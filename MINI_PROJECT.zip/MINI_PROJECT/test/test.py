import pickle
import numpy as np

# Function to load and validate the model
def load_model(model_path):
    try:
        with open(model_path, "rb") as f:
            model = pickle.load(f)
        
        # Print the type of model
        print(f"✅ Model Loaded Successfully! Type: {type(model)}")
        
        # Check if model has a 'predict' method
        if hasattr(model, 'predict'):
            print("✅ Model has a predict function. Ready for testing!")
            return model
        else:
            print("❌ Model does not have a predict function. This is not a valid ML model!")
            return None
    
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return None

# Function to test model with sample data
def test_model(model):
    if model is None:
        print("❌ Model is not loaded. Exiting test.")
        return
    
    try:
        # Example input (replace with actual test cases)
        sample_input = np.array([[5, 120, 80, 3, 150, 35, 0.5, 25]])  # (1, 8) shape

        print("\n🔍 Testing Model with Sample Input...")
        print("Input Data Shape:", sample_input.shape)

        # Check if the model can make predictions
        prediction = model.predict(sample_input)

        # Ensure the prediction is valid
        if len(prediction) == 0:
            print("❌ Model returned an empty prediction!")
        else:
            result = "Diabetic" if prediction[0] == 1 else "Not Diabetic"
            print(f"✅ Model Prediction: {result}")

    except Exception as e:
        print(f"❌ Error during prediction: {e}")

# 🔹 Provide the path to your trained model
model_path = r"C:\Users\hkask\OneDrive\Documents\chori\AIML-InternPe-Internship-main\Week_1\Project\model.pkl"  # Replace with actual path

# 🔹 Load the model
model = load_model(model_path)

# 🔹 Test the model
test_model(model)
